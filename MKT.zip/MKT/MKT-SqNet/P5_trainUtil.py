import time
import torch
from torch.nn.functional import kl_div
from tqdm import tqdm
from P6_utils import calculate_auc, calculate_acc, selecting_mask, calculate_lossGlobal, calculate_lossParams


def train(model, dataloaders, optimizer, file_logger, opt):
    model = torch.nn.DataParallel(model, device_ids=[0, 1])
    softmax = torch.nn.Softmax(dim=1)
    def run_epoch(train_eval_test):
        loss_epoch = 0
        predictRow_epoch = []
        nextLabelRow_epoch = []

        n_batch = 0
        train_loader = dataloaders[train_eval_test]
        for n_batch, batch in tqdm(enumerate(train_loader, start=1)):
            n_batch += 1
            effLens_batch, \
                currQuestionAddLabel_batch, currQuestionID_batch, \
                currSkillAddLabel_batch, currSkillID_batch, currSkill_oneHot_batch, \
                currLabel_batch, \
                nextQuestionID_batch, \
                nextSkillID_batch, nextSkill_oneHot_batch, \
                nextLabel_batch, currMetaCog_batch, nextMetaCog_batch = batch

            effLens_batch, \
                currQuestionAddLabel_batch, \
                currSkillAddLabel_batch, \
                nextQuestionID_batch, \
                nextSkillID_batch, nextSkill_oneHot_batch, \
                nextLabel_batch, currMetaCog_batch, nextMetaCog_batch = effLens_batch.to(opt.DEVICE), \
                currQuestionAddLabel_batch.to(opt.DEVICE), \
                currSkillAddLabel_batch.to(opt.DEVICE), \
                nextQuestionID_batch.to(opt.DEVICE), \
                nextSkillID_batch.to(opt.DEVICE), nextSkill_oneHot_batch.to(opt.DEVICE), \
                nextLabel_batch.to(opt.DEVICE), currMetaCog_batch.to(opt.DEVICE), nextMetaCog_batch.to(opt.DEVICE)

            bsz, maxLen_batch = currSkillAddLabel_batch.size()
            maskEffLen_batch = selecting_mask(effLen=effLens_batch, maxLen=maxLen_batch, opt=opt)
            nextLabelRow_batch = nextLabel_batch.masked_select(maskEffLen_batch)
            nextLabelRow_epoch.append(nextLabelRow_batch.detach().cpu())

            if train_eval_test == 'train':
                model.train()
                optimizer.zero_grad()
            else:
                model.eval()

            predict_batch, predictAllSkill_batch, [L_skill, G, S], [embCurrCog_observ, embCurrCog_repres, embcurrMetaCog_observ,
                embcurrMetaCog_repres, nextInput_observ, nextInput_repres, embnextMetaCog_observ, embnextMetaCog_repres,
                embCurrCog_shared, nextInput_shared, embcurrMetaCog_shared, embnextMetaCog_shared] = model.forward(currSkillAddLabel_batch, currQuestionAddLabel_batch, nextSkill_oneHot_batch, nextSkillID_batch, nextQuestionID_batch, currMetaCog_batch, nextMetaCog_batch)

            if train_eval_test == 'train':
                lossD_batch = calculate_lossGlobal(predict_batch, nextLabel_batch, maskEffLen_batch)
                lossParam_batch, lossList = calculate_lossParams([L_skill, G, S], nextSkill_oneHot_batch, effLens_batch, opt)
                loss_vib = kl_div(input=softmax(embCurrCog_observ), target=softmax(embCurrCog_repres)) + \
                           kl_div(input=softmax(embcurrMetaCog_observ), target=softmax(embcurrMetaCog_repres)) + \
                           kl_div(input=softmax(nextInput_observ), target=softmax(nextInput_repres)) + \
                           kl_div(input=softmax(embnextMetaCog_observ), target=softmax(embnextMetaCog_repres)) + \
                           0.5 * kl_div(input=softmax(embCurrCog_shared), target=softmax(embCurrCog_repres)) + \
                           0.5 * kl_div(input=softmax(nextInput_shared), target=softmax(nextInput_repres)) + \
                           0.5 * kl_div(input=softmax(embcurrMetaCog_shared), target=softmax(embcurrMetaCog_repres)) + \
                           0.5 * kl_div(input=softmax(embnextMetaCog_shared), target=softmax(embnextMetaCog_repres))

                (lossD_batch + lossParam_batch + loss_vib).backward()

                if n_batch == 1:
                    print('lossD_batch=%d' % lossD_batch)

                optimizer.step()
                loss_epoch += lossD_batch.item()

            predictRow_batch = predict_batch.masked_select(maskEffLen_batch)
            predictRow_epoch.append(predictRow_batch.detach().cpu())

        nextLabelRow_epoch = torch.cat(nextLabelRow_epoch)
        loss_epoch /= n_batch
        predictRow_epoch = torch.cat(predictRow_epoch)
        auc_epoch = calculate_auc(predictRow_epoch, nextLabelRow_epoch)
        acc_epoch = calculate_acc(predictRow_epoch, nextLabelRow_epoch)

        if train_eval_test == 'train':
            print('epoch %3d %5s \t\t|| acc=%.3f  auc=%.3f' % (epoch, train_eval_test, acc_epoch, auc_epoch))
            file_logger.info('epoch %3d %5s \t\t|| acc=%.3f  auc=%.3f' % (epoch, train_eval_test, acc_epoch, auc_epoch))
        else:
            print('epoch %3d %5s \t\t|| acc=%.3f  auc=%.3f' % (epoch, train_eval_test, acc_epoch, auc_epoch))
            file_logger.info('epoch %3d %5s \t\t|| acc=%.3f  auc=%.3f' % (epoch, train_eval_test, acc_epoch, auc_epoch))

        return auc_epoch, acc_epoch

    bestEpoch = 1
    bestAucEval = 0
    aucTestList = []
    accTestList = []

    for epoch in range(1, opt.n_epoch + 1):
        train_start_time = time.time()
        aucTrain, accTrain = run_epoch('train')
        print("Training Cost Time:", time.time() - train_start_time)
        aucEval, accEval = run_epoch('eval')
        test_start_time = time.time()
        aucTest, accTest = run_epoch('test')
        print("Test Cost Time:", time.time() - test_start_time)

        aucTestList.append(aucTest)
        accTestList.append(accTest)
        if aucEval > bestAucEval:
            bestAucEval = aucEval
            bestEpoch = epoch

        if epoch - bestEpoch >= 30:
            break

    bestAucTest = aucTestList[bestEpoch - 1]
    bestAccTest = accTestList[bestEpoch - 1]
    file_logger.info('bestEpoch=%d \n bestAucTest=%.6f \n bestAccTest=%.6f' % (bestEpoch, bestAucTest, bestAccTest))
    print('bestEpoch=%d \n bestAucTest=%.6f \n bestAccTest=%.6f' % (bestEpoch, bestAucTest, bestAccTest))