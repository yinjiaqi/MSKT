from tqdm import tqdm


cog_col_list = ['video_back_num_all_acc', 'video_play_num_all_acc', 'video_pause_num_all_acc', 'video_drag_num_all_acc',
                'view_analysis_num_all_acc', 'view_report_num_acc', 'mouse_num_all_acc', 'login_num_acc',
                'video_skip_num_all_acc', 'video_unplayed_skip_num_all_acc', 'module_num_acc', 'video_back_num_acc',
                'video_play_num_acc', 'video_pause_num_acc', 'video_drag_num_acc', 'view_analysis_num_acc',
                'mouse_num_acc', 'video_skip_num_acc', 'video_unplayed_skip_num_acc']


def read_csv(one_data):
    all_stu = list(set(list(one_data['account_id'])))
    one_data.index = list(one_data['account_id'])
    effLen = []
    questionID = []
    skillID = []
    label = []
    cog_data = []

    for one_stu in tqdm(all_stu):
        one_stu_data = one_data.loc[one_stu]
        effLen.append(len(one_stu_data))
        questionID.append(list(one_stu_data['q_id']))
        skillID.append(list(one_stu_data['tag_code']))
        label.append(list(one_stu_data['is_right']))
        cog_data.append(one_stu_data[cog_col_list].values)
    return effLen, questionID, skillID, label, cog_data
