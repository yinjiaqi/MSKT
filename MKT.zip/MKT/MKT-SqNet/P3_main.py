# import os
# os.environ['CUDA_VISIBLE_DEVICES'] = '1'
import pandas as pd
from P0_config import set_opt
from P1_dataUtil import read_csv
from P2_dataset import KTDataset, PadSequence
from P4_model_Our import DKTInSkillQues
from P5_trainUtil import train
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader
import torch
from torch.optim import Adam
import datetime
import logging
import os


cog_col_list = ['video_back_num_all_acc', 'video_play_num_all_acc', 'video_pause_num_all_acc', 'video_drag_num_all_acc',
                'view_analysis_num_all_acc', 'view_report_num_acc', 'mouse_num_all_acc', 'login_num_acc',
                'video_skip_num_all_acc', 'video_unplayed_skip_num_all_acc', 'module_num_acc', 'video_back_num_acc',
                'video_play_num_acc', 'video_pause_num_acc', 'video_drag_num_acc', 'view_analysis_num_acc',
                'mouse_num_acc', 'video_skip_num_acc', 'video_unplayed_skip_num_acc']


def trainComplementaryModel_main():
    RAW_DATA = pd.read_pickle("./data/pkt/allgrade.pkl")
    all_stu_id = list(RAW_DATA['account_id'].value_counts().index)
    X_train_eval, X_test = train_test_split(all_stu_id, random_state=2000, test_size=0.2, shuffle=True)
    X_train, X_eavl = train_test_split(X_train_eval, random_state=2000, test_size=0.2, shuffle=True)
    RAW_DATA.index = list(RAW_DATA['account_id'])
    train_data = RAW_DATA.loc[X_train].reset_index(drop=True)
    eval_data = RAW_DATA.loc[X_eavl].reset_index(drop=True)
    test_data = RAW_DATA.loc[X_test].reset_index(drop=True)

    opt.n_skill = max(RAW_DATA['tag_code'])
    opt.n_skillPad = opt.n_skill + 1
    opt.n_question = max(RAW_DATA['q_id'])
    opt.n_questionPad = opt.n_question + 1

    MODEL_NAME = 'PKT'
    ONE_DATASET = 'allgrade'
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging.shutdown()
    time_now = datetime.datetime.now()
    now_str = time_now.strftime('%Y-%m-%d-%H-%M-%S')
    log_dir = f'log/{MODEL_NAME}/{ONE_DATASET}'
    log_file_name = f'{log_dir}/{now_str}.log'
    os.makedirs(log_dir, exist_ok=True)
    logging.basicConfig(level=logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(message)s')
    file_logger = logging.getLogger(log_file_name)

    file_handler = logging.FileHandler(log_file_name, mode='a', encoding='utf-8')
    file_handler.setFormatter(formatter)
    file_logger.addHandler(file_handler)
    file_logger.info(f"Model: {MODEL_NAME}; Dataset: {ONE_DATASET}")

    datasets = {'train': read_csv(train_data), 'eval': read_csv(eval_data), 'test': read_csv(test_data)}

    datasets = {'train': KTDataset(seqLen_allSample=datasets['train'][0],
                                   questionID_allSample=datasets['train'][1],
                                   skillID_allSample=datasets['train'][2],
                                   label_allSample=datasets['train'][3],
                                   cog_data=datasets['train'][4],
                                   n_question=opt.n_question, n_skill=opt.n_skill,
                                   opt=opt),
                'eval': KTDataset(datasets['eval'][0],
                                  datasets['eval'][1],
                                  datasets['eval'][2],
                                  datasets['eval'][3],
                                  datasets['eval'][4],
                                  opt.n_question, opt.n_skill,
                                  opt=opt),
                'test': KTDataset(datasets['test'][0],
                                  datasets['test'][1],
                                  datasets['test'][2],
                                  datasets['test'][3],
                                  datasets['test'][4],
                                  opt.n_question, opt.n_skill,
                                  opt=opt)}

    dataloaders = {'train': DataLoader(dataset=datasets['train'],
                                       batch_size=opt.bsz,
                                       drop_last=False,
                                       collate_fn=PadSequence(),
                                       shuffle=opt.shuffleDataloader),
                   'eval': DataLoader(dataset=datasets['eval'],
                                       batch_size=opt.bsz,
                                       drop_last=False,
                                       collate_fn=PadSequence(),
                                       shuffle=opt.shuffleDataloader),
                   'test': DataLoader(dataset=datasets['test'],
                                      batch_size=opt.bsz,
                                      drop_last=False,
                                      collate_fn=PadSequence(),
                                      shuffle=opt.shuffleDataloader)}

    model = DKTInSkillQues(nSkill=opt.n_skill, nQues=opt.n_question, szRnnIn=opt.sz_rnn_in, szRnnOut=opt.sz_rnn_out,
                           nRnnLayer=opt.n_rnn_layer, szOut=opt.n_skillPad, dropout=opt.rnn_dropout,
                           cog_len=len(cog_col_list), opt=opt).to(opt.DEVICE)
    optimizer = Adam(model.parameters(), lr=opt.lr)
    train(model, dataloaders, optimizer, file_logger, opt)


if __name__ == '__main__':
    opt = set_opt()
    torch.manual_seed(opt.seed)
    trainComplementaryModel_main()
