data_folder = 'datasets'


def get_csv_fname(trainEvalTest, dataset, datasetNum):
    if trainEvalTest == 'train':
        fname = './data/train%s.csv'%datasetNum
    elif trainEvalTest == 'eval':
        fname = './data/test%s.csv'%datasetNum
    else:
        fname = './data/test%s.csv'%datasetNum
    return '%s' % (fname)


def get_num_skill(dataset):
    if dataset == 'assist0910':
        return 110
    elif dataset == 'assist17':
        return 102
    elif dataset == 'static11':
        return 110
    elif dataset == 'EdNet':
        return 1791
    elif dataset == 'Eedi':
        return 700
    elif dataset == 'fsaif1tof3':
        return 1148
    else:
        raise NotImplementedError('Invalid Dataset')


def get_num_question(dataset):
    if dataset == 'assist0910':
        return 16891
    elif dataset == 'assist17':
        return 3162
    elif dataset == 'static11':
        return 633
    elif dataset == 'EdNet':
        return 18143
    elif dataset == 'Eedi':
        return 950
    elif dataset == 'fsaif1tof3':
        return 24320
    else:
        raise NotImplementedError('Invalid Dataset')


def read_csv(fname, minimum_seq_len, maximum_seq_len=10000):
    with open(fname, 'r') as f:
        data = f.read()
    data = data.split('\n')
    while data[0] == '':
        data = data[1:]
    while data[-1] == '':
        data = data[:-1]
    effLen = []
    questionID = []
    skillID = []
    label = []

    explain_quest_user, explain_skill_user, audio_quest_user, audio_skill_user, video_quest_user, video_skill_user, \
    erase_quest_user, erase_skill_user, revise_quest_user, revise_skill_user, audio_time_user, video_time_user = [], [], [], [], [], [], [], [], [], [], [], []

    i = 0
    while i < len(data):
        line = data[i]
        if i % 16 == 0:
            if maximum_seq_len >= int(line) >= minimum_seq_len:
                effLen.append(int(line))
            else:
                i += 16
                continue
        elif i % 16 == 1:
            line = line.split(',')
            questionID.append([int(e) for e in line if e != ''])
        elif i % 16 == 2:
            line = line.split(',')
            skillID.append([int(e) for e in line if e != ''])
        elif i % 16 == 3:
            line = line.split(',')
            explain_quest_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 4:
            line = line.split(',')
            explain_skill_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 5:
            line = line.split(',')
            audio_quest_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 6:
            line = line.split(',')
            audio_skill_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 7:
            line = line.split(',')
            audio_time_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 8:
            line = line.split(',')
            video_quest_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 9:
            line = line.split(',')
            video_skill_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 10:
            line = line.split(',')
            video_time_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 11:
            line = line.split(',')
            erase_quest_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 12:
            line = line.split(',')
            erase_skill_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 13:
            line = line.split(',')
            revise_quest_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 14:
            line = line.split(',')
            revise_skill_user.append([float(e) for e in line if e != ''])
        elif i % 16 == 15:
            line = line.split(',')
            label.append([int(e) for e in line if e != ''])

            assert effLen[-1] == len(questionID[-1]) == len(skillID[-1]) == len(explain_quest_user[-1]) == len(explain_skill_user[-1]) == len(audio_quest_user[-1]) == \
                   len(audio_skill_user[-1]) == len(video_quest_user[-1]) == len(video_skill_user[-1]) == len(erase_quest_user[-1]) == len(erase_skill_user[-1]) == \
                   len(revise_quest_user[-1]) == len(revise_skill_user[-1]) == len(label[-1]) == len(audio_time_user[-1]) == len(video_time_user[-1])
        else:
            pass
        i += 1

    return (effLen, questionID, skillID, explain_quest_user, explain_skill_user, audio_quest_user, audio_skill_user,
            video_quest_user, video_skill_user, erase_quest_user, erase_skill_user, revise_quest_user, revise_skill_user,
            audio_time_user, video_time_user, label)
