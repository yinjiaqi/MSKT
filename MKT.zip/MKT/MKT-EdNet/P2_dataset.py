from typing import List, Tuple
import torch
from torch.utils.data import Dataset
import numpy as np


class KTDataset(Dataset):
    def __init__(self, seqLen_allSample, questionID_allSample, skillID_allSample, explain_quest, explain_skill,
                 audio_quest, audio_skill, video_quest, video_skill, erase_quest, erase_skill,
                 revise_quest, revise_skill, audio_time, video_time, label_allSample, n_question, n_skill, opt):
        assert len(seqLen_allSample) == len(questionID_allSample) == len(skillID_allSample) == len(label_allSample) == \
               len(explain_quest) == len(explain_skill) == len(audio_quest) == len(audio_skill) == \
               len(video_quest) == len(video_skill) == len(erase_quest) == len(erase_skill) == len(revise_quest) == len(revise_skill) == \
               len(audio_time) == len(video_time)
        self.seq_lengths_all = seqLen_allSample
        self.questionID_allSample = questionID_allSample
        self.skillID_allSample = skillID_allSample
        self.explain_quest, self.explain_skill, self.audio_quest, self.audio_skill, self.video_quest, self.video_skill, \
        self.erase_quest, self.erase_skill, self.revise_quest, self.revise_skill, self.audio_time, self.video_time = explain_quest, explain_skill, audio_quest, \
        audio_skill, video_quest, video_skill, erase_quest, erase_skill, revise_quest, revise_skill, audio_time, video_time
        self.correctness_all = label_allSample
        self.n_question = n_question
        self.n_skill = n_skill
        self.eyeSkill = np.eye(n_skill + 1)
        self.opt = opt

    def __len__(self):
        return len(self.seq_lengths_all)

    def __getitem__(self, index: int):
        effLen_1Sample = self.seq_lengths_all[index] - 1
        questionID_1Sample = np.array(self.questionID_allSample[index], dtype=np.int32)
        skillID_1Sample = np.array(self.skillID_allSample[index], dtype=np.int32)
        label_1Sample = np.array(self.correctness_all[index], dtype=np.int32)

        explain_quest = np.array(self.explain_quest[index], dtype=np.int32)
        explain_skill = np.array(self.explain_skill[index], dtype=np.int32)
        audio_quest = np.array(self.audio_quest[index], dtype=np.int32)
        audio_skill = np.array(self.audio_skill[index], dtype=np.int32)
        audio_time = np.array(self.audio_time[index], dtype=np.float32)
        video_quest = np.array(self.video_quest[index], dtype=np.int32)
        video_skill = np.array(self.video_skill[index], dtype=np.int32)
        video_time = np.array(self.video_time[index], dtype=np.float32)
        erase_quest = np.array(self.erase_quest[index], dtype=np.int32)
        erase_skill = np.array(self.erase_skill[index], dtype=np.int32)
        revise_quest = np.array(self.revise_quest[index], dtype=np.int32)
        revise_skill = np.array(self.revise_skill[index], dtype=np.int32)

        currQuestionAddLabel_1Sample = label_1Sample[:-1] * self.n_question + questionID_1Sample[:-1]
        currQuestionID_1Sample = questionID_1Sample[:-1]
        currSkillAddLabel_1Sample = label_1Sample[:-1] * self.n_skill + skillID_1Sample[:-1]
        currSkillID_1Sample = skillID_1Sample[:-1]
        currSkill_oneHot_1Sample = self.eyeSkill[skillID_1Sample[:-1]]
        currLabel_1Sample = label_1Sample[:-1]

        currexplain_quest = explain_quest[:-1]
        currexplain_skill = explain_skill[:-1]
        curr_audio_quest = audio_quest[:-1]
        curr_audio_skill = audio_skill[:-1]
        curr_audio_time = audio_time[:-1]
        curr_video_quest = video_quest[:-1]
        curr_video_skill = video_skill[:-1]
        curr_video_time = video_time[:-1]
        currerase_quest = erase_quest[:-1]
        currerase_skill = erase_skill[:-1]
        currrevise_quest = revise_quest[:-1]
        currrevise_skill = revise_skill[:-1]

        nextQuestionID_1Sample = questionID_1Sample[1:]
        nextSkillID_1Sample = skillID_1Sample[1:]
        nextSkill_oneHot_1Sample = self.eyeSkill[skillID_1Sample[1:]]
        nextLabel_1Sample = label_1Sample[1:]

        nextexplain_quest = explain_quest[1:]
        nextexplain_skill = explain_skill[1:]
        next_audio_quest = audio_quest[1:]
        next_audio_skill = audio_skill[1:]
        next_audio_time = audio_time[1:]
        next_video_quest = video_quest[1:]
        next_video_skill = video_skill[1:]
        next_video_time = video_time[1:]
        nexterase_quest = erase_quest[1:]
        nexterase_skill = erase_skill[1:]
        nextrevise_quest = revise_quest[1:]
        nextrevise_skill = revise_skill[1:]

        return (torch.LongTensor([effLen_1Sample]),
               torch.LongTensor(currQuestionAddLabel_1Sample), torch.LongTensor(currQuestionID_1Sample),
               torch.LongTensor(currSkillAddLabel_1Sample), torch.LongTensor(currSkillID_1Sample), torch.FloatTensor(currSkill_oneHot_1Sample),
               torch.FloatTensor(currLabel_1Sample), torch.FloatTensor(currexplain_quest), torch.FloatTensor(currexplain_skill),
               torch.FloatTensor(curr_audio_quest), torch.FloatTensor(curr_audio_skill), torch.FloatTensor(curr_audio_time),
               torch.FloatTensor(curr_video_quest), torch.FloatTensor(curr_video_skill), torch.FloatTensor(curr_video_time),
               torch.FloatTensor(currerase_quest), torch.FloatTensor(currerase_skill),
               torch.FloatTensor(currrevise_quest), torch.FloatTensor(currrevise_skill),
               torch.LongTensor(nextQuestionID_1Sample), torch.LongTensor(nextSkillID_1Sample), torch.FloatTensor(nextSkill_oneHot_1Sample), torch.FloatTensor(nextLabel_1Sample),
               torch.FloatTensor(nextexplain_quest), torch.FloatTensor(nextexplain_skill), torch.FloatTensor(next_audio_quest), torch.FloatTensor(next_audio_skill),
               torch.FloatTensor(next_audio_time), torch.FloatTensor(next_video_quest), torch.FloatTensor(next_video_skill), torch.FloatTensor(next_video_time),
               torch.FloatTensor(nexterase_quest), torch.FloatTensor(nexterase_skill), torch.FloatTensor(nextrevise_quest), torch.FloatTensor(nextrevise_skill))


class PadSequence(object):
    def __call__(self, batch: List[Tuple[torch.Tensor]]):
        batch = sorted(batch, key=lambda y: y[0].shape[0], reverse=True)

        effLen = torch.cat([x[0] for x in batch])

        currQuestionAddLabel = torch.nn.utils.rnn.pad_sequence([x[1] for x in batch], batch_first=True, padding_value=0)
        currQuestionID = torch.nn.utils.rnn.pad_sequence([x[2] for x in batch], batch_first=True, padding_value=0)

        currSkillAddLabel = torch.nn.utils.rnn.pad_sequence([x[3] for x in batch], batch_first=True, padding_value=0)
        currSkillID = torch.nn.utils.rnn.pad_sequence([x[4] for x in batch], batch_first=True, padding_value=0)
        currSkill_oneHot = torch.nn.utils.rnn.pad_sequence([x[5] for x in batch], batch_first=True)

        currLabel = torch.nn.utils.rnn.pad_sequence([x[6] for x in batch], batch_first=True, padding_value=0)

        currexplain_quest = torch.nn.utils.rnn.pad_sequence([x[7] for x in batch], batch_first=True, padding_value=0)
        currexplain_skill = torch.nn.utils.rnn.pad_sequence([x[8] for x in batch], batch_first=True, padding_value=0)
        curr_audio_quest = torch.nn.utils.rnn.pad_sequence([x[9] for x in batch], batch_first=True, padding_value=0)
        curr_audio_skill = torch.nn.utils.rnn.pad_sequence([x[10] for x in batch], batch_first=True, padding_value=0)
        curr_audio_time = torch.nn.utils.rnn.pad_sequence([x[11] for x in batch], batch_first=True, padding_value=0)
        curr_video_quest = torch.nn.utils.rnn.pad_sequence([x[12] for x in batch], batch_first=True, padding_value=0)
        curr_video_skill = torch.nn.utils.rnn.pad_sequence([x[13] for x in batch], batch_first=True, padding_value=0)
        curr_video_time = torch.nn.utils.rnn.pad_sequence([x[14] for x in batch], batch_first=True, padding_value=0)
        currerase_quest = torch.nn.utils.rnn.pad_sequence([x[15] for x in batch], batch_first=True, padding_value=0)
        currerase_skill = torch.nn.utils.rnn.pad_sequence([x[16] for x in batch], batch_first=True, padding_value=0)
        currrevise_quest = torch.nn.utils.rnn.pad_sequence([x[17] for x in batch], batch_first=True, padding_value=0)
        currrevise_skill = torch.nn.utils.rnn.pad_sequence([x[18] for x in batch], batch_first=True, padding_value=0)

        nextQuestionID = torch.nn.utils.rnn.pad_sequence([x[19] for x in batch], batch_first=True, padding_value=0)

        nextSkillID = torch.nn.utils.rnn.pad_sequence([x[20] for x in batch], batch_first=True, padding_value=0)
        nextSkill_oneHot = torch.nn.utils.rnn.pad_sequence([x[21] for x in batch], batch_first=True)

        nextLabel = torch.nn.utils.rnn.pad_sequence([x[22] for x in batch], batch_first=True, padding_value=0)

        nextexplain_quest = torch.nn.utils.rnn.pad_sequence([x[23] for x in batch], batch_first=True, padding_value=0)
        nextexplain_skill = torch.nn.utils.rnn.pad_sequence([x[24] for x in batch], batch_first=True, padding_value=0)
        next_audio_quest = torch.nn.utils.rnn.pad_sequence([x[25] for x in batch], batch_first=True, padding_value=0)
        next_audio_skill = torch.nn.utils.rnn.pad_sequence([x[26] for x in batch], batch_first=True, padding_value=0)
        next_audio_time = torch.nn.utils.rnn.pad_sequence([x[27] for x in batch], batch_first=True, padding_value=0)
        next_video_quest = torch.nn.utils.rnn.pad_sequence([x[28] for x in batch], batch_first=True, padding_value=0)
        next_video_skill = torch.nn.utils.rnn.pad_sequence([x[29] for x in batch], batch_first=True, padding_value=0)
        next_video_time = torch.nn.utils.rnn.pad_sequence([x[30] for x in batch], batch_first=True, padding_value=0)
        nexterase_quest = torch.nn.utils.rnn.pad_sequence([x[31] for x in batch], batch_first=True, padding_value=0)
        nexterase_skill = torch.nn.utils.rnn.pad_sequence([x[32] for x in batch], batch_first=True, padding_value=0)
        nextrevise_quest = torch.nn.utils.rnn.pad_sequence([x[33] for x in batch], batch_first=True, padding_value=0)
        nextrevise_skill = torch.nn.utils.rnn.pad_sequence([x[34] for x in batch], batch_first=True, padding_value=0)

        return (effLen,
               currQuestionAddLabel, currQuestionID,
               currSkillAddLabel, currSkillID,currSkill_oneHot,
               currLabel, currexplain_quest, currexplain_skill, curr_audio_quest, curr_audio_skill, curr_audio_time,
               curr_video_quest, curr_video_skill, curr_video_time, currerase_quest, currerase_skill, currrevise_quest, currrevise_skill,
               nextQuestionID, nextSkillID, nextSkill_oneHot, nextLabel, nextexplain_quest, nextexplain_skill,
               next_audio_quest, next_audio_skill, next_audio_time, next_video_quest, next_video_skill, next_video_time,
               nexterase_quest, nexterase_skill, nextrevise_quest, nextrevise_skill)
