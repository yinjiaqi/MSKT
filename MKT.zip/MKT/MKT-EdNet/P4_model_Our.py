import torch
import numpy as np
import torch.nn as nn
from timm.models.layers import Mlp


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, attn_drop=0., proj_drop=0.):
        super().__init__()
        assert dim % num_heads == 0, 'dim should be divisible by num_heads'
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5

        self.cog = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.metacog = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def mask(self, dim):
        diagonal = np.ones((dim, dim))
        mask = torch.tensor(np.triu(diagonal, k=1))

        return mask == 1

    def forward(self, x, y):
        B, N, C = x.shape
        qkv_cog = self.cog(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q_cog, k_cog, v_cog = qkv_cog.unbind(0)
        qk_metacog = self.metacog(y).reshape(B, N, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q_metacog, k_metacog = qk_metacog.unbind(0)
        q, k, v = q_cog + q_metacog, k_cog + k_metacog, v_cog

        attn = (q @ k.transpose(-2, -1)) * self.scale
        mask = self.mask(N).to(x.device)
        attn = attn.masked_fill(mask, value=1e-5)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class LayerScale(nn.Module):
    def __init__(self, dim, init_values=1e-5, inplace=False):
        super().__init__()
        self.inplace = inplace
        self.gamma = nn.Parameter(init_values * torch.ones(dim))

    def forward(self, x):
        return x.mul_(self.gamma) if self.inplace else x * self.gamma


class Block(nn.Module):

    def __init__(
            self, dim, num_heads, mlp_ratio=4., qkv_bias=False, drop=0., attn_drop=0., init_values=None,
            drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.norm2 = norm_layer(dim)
        self.attn = Attention(dim, num_heads=num_heads, qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop)
        self.ls1 = LayerScale(dim, init_values=init_values) if init_values else nn.Identity()
        # NOTE: drop path for stochastic depth, we shall see if this is better than dropout here
        self.drop_path1 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.norm3 = norm_layer(dim)
        self.mlp = Mlp(in_features=dim, hidden_features=int(dim * mlp_ratio), act_layer=act_layer, drop=drop)
        self.ls2 = LayerScale(dim, init_values=init_values) if init_values else nn.Identity()
        self.drop_path2 = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x, y):
        x = x + self.drop_path1(self.ls1(self.attn(self.norm1(x), self.norm2(y))))
        x = x + self.drop_path2(self.ls2(self.mlp(self.norm3(x))))
        return x


def weights_init_classifier(m):
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        nn.init.normal_(m.weight.data, std=0.001)
        nn.init.constant_(m.bias.data, 0.0)


class VIB(nn.Module):
    def __init__(self, in_ch=128):
        super(VIB, self).__init__()
        self.in_ch = in_ch

        bottleneck = []

        if in_ch == 128:
            bottleneck += [nn.Linear(self.in_ch, self.in_ch)]
        else:
            bottleneck += [nn.Linear(128, self.in_ch)]
            bottleneck += [nn.Linear(self.in_ch, 128)]

        bottleneck += [nn.LayerNorm(128)]
        bottleneck += [nn.LeakyReLU(0.1)]

        bottleneck = nn.Sequential(*bottleneck)
        self.bottleneck = bottleneck
        self.bottleneck.apply(weights_init_classifier)

    def forward(self, v):
        z_given_v = self.bottleneck(v)
        return z_given_v


class DKTInSkillQues(nn.Module):

    def __init__(self, nSkill, nQues, szRnnIn, szRnnOut, nRnnLayer, szOut, dropout, opt):
        super(DKTInSkillQues, self).__init__()
        self.encoderSkillLabel = nn.Embedding(num_embeddings=2 * nSkill + 1, embedding_dim=szRnnIn, padding_idx=0)
        self.encoderQuesLabel = nn.Embedding(num_embeddings=2 * nQues + 1, embedding_dim=szRnnIn, padding_idx=0)

        dpr = [x.item() for x in torch.linspace(0, 0., 1)]
        self.pos_embed = nn.Embedding(num_embeddings=10000, embedding_dim=128)
        self.transformer = Block(dim=128, num_heads=8, mlp_ratio=4, qkv_bias=True, init_values=None, drop=0.,
                                 attn_drop=0., drop_path=dpr[0], norm_layer=nn.LayerNorm, act_layer=nn.GELU)
        self.rnn = nn.LSTM(input_size=szRnnIn, hidden_size=szRnnOut, num_layers=nRnnLayer, batch_first=True, dropout=dropout)

        self.encoderNextSkill = nn.Embedding(num_embeddings=nSkill + 1, embedding_dim=szRnnOut, padding_idx=0)
        self.encoderNextQues = nn.Embedding(num_embeddings=nQues + 1, embedding_dim=szRnnOut, padding_idx=0)

        self.currMetaProj = torch.nn.Linear(12, szRnnIn)

        self.nextMetaProj = torch.nn.Linear(12, szRnnOut)

        self.Meta_Bottleneck = VIB(in_ch=64)
        self.Norm_Bottleneck = VIB(in_ch=64)
        self.Shar_Bottleneck = VIB(in_ch=64)

        self.transL = nn.Linear(2 * szRnnOut, szOut)
        self.transDiff = nn.Linear(szRnnOut, szOut)
        self.transAlpha = nn.Linear(szRnnOut, szOut)
        self.transK = nn.Linear(2 * szRnnOut, szOut)
        self.transG = nn.Linear(2 * szRnnOut, szOut)
        self.transS = nn.Linear(2 * szRnnOut, szOut)

        self.sigmoid = nn.Sigmoid()
        self.opt = opt

    def forward(self, currSkillAddLabel, currQuesAddLabel, nextSkill_oneHot, nextSkillID, nextQuesID,
                currexplain_quest, currexplain_skill, curr_audio_quest, curr_audio_skill, curr_audio_time, curr_video_quest,
                curr_video_skill, curr_video_time, currerase_quest, currerase_skill, currrevise_quest, currrevise_skill, nextexplain_quest,
                nextexplain_skill, next_audio_quest, next_audio_skill, next_audio_time, next_video_quest, next_video_skill, next_video_time, nexterase_quest,
                nexterase_skill, nextrevise_quest, nextrevise_skill):
        embSkillLabel = self.encoderSkillLabel(currSkillAddLabel)  # Concept-Answer e_ca 128
        embQuesLabel = self.encoderQuesLabel(currQuesAddLabel)  # Question-Answer d_qa 128
        difficultySkillLabel = self.sigmoid(embQuesLabel)
        embCurrCog_observ = embSkillLabel * (1 + difficultySkillLabel)  # Combine e_ca with d_qa 128
        embCurrCog_repres = self.Norm_Bottleneck(embCurrCog_observ)
        embCurrCog_shared = self.Shar_Bottleneck(embCurrCog_repres)

        curr_audio_time = torch.nn.functional.normalize(curr_audio_time, p=1, dim=-1)
        curr_video_time = torch.nn.functional.normalize(curr_video_time, p=1, dim=-1)
        next_audio_time = torch.nn.functional.normalize(next_audio_time, p=1, dim=-1)
        next_video_time = torch.nn.functional.normalize(next_video_time, p=1, dim=-1)

        currMetaCog = torch.cat(
            (currexplain_quest.unsqueeze(-1), currexplain_skill.unsqueeze(-1), curr_audio_quest.unsqueeze(-1),
             curr_audio_skill.unsqueeze(-1), curr_audio_time.unsqueeze(-1), curr_video_quest.unsqueeze(-1),
             curr_video_skill.unsqueeze(-1), curr_video_time.unsqueeze(-1), currerase_quest.unsqueeze(-1),
             currerase_skill.unsqueeze(-1), currrevise_quest.unsqueeze(-1), currrevise_skill.unsqueeze(-1)), dim=-1)

        embcurrMetaCog_observ = self.sigmoid(self.currMetaProj(currMetaCog))
        embcurrMetaCog_repres = self.Meta_Bottleneck(embcurrMetaCog_observ)
        embcurrMetaCog_shared = self.Shar_Bottleneck(embcurrMetaCog_repres)

        pos_in = self.pos_embed(torch.arange(embCurrCog_shared.size(1)).unsqueeze(0).cuda())
        rnn_output = self.transformer(embCurrCog_shared + pos_in, embcurrMetaCog_shared + pos_in)
        rnn_output, self.hidden_state = self.rnn(rnn_output)

        embNextSkill = self.encoderNextSkill(nextSkillID)  # Concept e_c 128
        embNextQues = self.encoderNextQues(nextQuesID)  # Question d_q 128
        difficultyNextSkill = self.sigmoid(embNextQues)

        nextInput_observ = embNextSkill * (1 + difficultyNextSkill)
        nextInput_repres = self.Norm_Bottleneck(nextInput_observ)
        nextInput_shared = self.Shar_Bottleneck(nextInput_repres)

        nextMetaCog = torch.cat(
            (nextexplain_quest.unsqueeze(-1), nextexplain_skill.unsqueeze(-1), next_audio_quest.unsqueeze(-1),
             next_audio_skill.unsqueeze(-1), next_audio_time.unsqueeze(-1), next_video_quest.unsqueeze(-1),
             next_video_skill.unsqueeze(-1), next_video_time.unsqueeze(-1), nexterase_quest.unsqueeze(-1),
             nexterase_skill.unsqueeze(-1), nextrevise_quest.unsqueeze(-1), nextrevise_skill.unsqueeze(-1)), dim=-1)

        embnextMetaCog_observ = self.sigmoid(self.nextMetaProj(nextMetaCog))
        embnextMetaCog_repres = self.Meta_Bottleneck(embnextMetaCog_observ)
        embnextMetaCog_shared = self.Shar_Bottleneck(embnextMetaCog_repres)

        nextOutput = nextInput_shared + embnextMetaCog_shared

        nextFullInfo = torch.cat([rnn_output, nextOutput], dim=2)  # Concept Grasp

        L_skill = self.sigmoid(self.transL(nextFullInfo))  # Concept mastery
        Diff = self.sigmoid(self.transDiff(embNextQues))  # Question solving
        q_alpha = self.sigmoid(self.transAlpha(embNextQues))  # Question solving
        G = self.sigmoid(self.transG(nextFullInfo))  # Answering behavior
        S = self.sigmoid(self.transS(nextFullInfo))  # Answering behavior

        x = 4 * q_alpha * (L_skill - Diff)  # Question solving
        L = torch.exp(x) / (1 + torch.exp(x))  # Question solving

        c1 = L * (1 - S)
        c2 = (1 - L) * G

        predictAllSkill = c1 + c2

        predict = torch.sum(predictAllSkill * nextSkill_oneHot, dim=2)

        return (predict, predictAllSkill, [L_skill, G, S], [embCurrCog_observ, embCurrCog_repres, embcurrMetaCog_observ,
                                                            embcurrMetaCog_repres, nextInput_observ, nextInput_repres,
                                                            embnextMetaCog_observ, embnextMetaCog_repres,
                                                            embCurrCog_shared, nextInput_shared, embcurrMetaCog_shared,
                                                            embnextMetaCog_shared])
